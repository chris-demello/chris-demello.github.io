/*
* Christopher DeMello
* Dr. Godbold
* CS360 Mod 7-2
* 15 Dec 2024
* Modified: 2/4/26
* */

package com.CS360.weighttracker;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.CS360.weighttracker.model.GoalWeight;
import com.CS360.weighttracker.model.WeightEntry;
import com.CS360.weighttracker.Dao.AppDatabase;
import com.CS360.weighttracker.repository.WeightRepository;
import com.CS360.weighttracker.service.GoalService;
import com.CS360.weighttracker.util.InputValidator;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/*
Logic behind main activity. This allows a user to view the grid system (recyclerview) where a user
can set their goal weight by clicking the scale icon in the app bar. The user can set their daily
weight entry with the FAB in the bottom right. The user can delete any row by clicking on the trash
can.
 */

public class MainActivity extends AppCompatActivity
    implements WeightEntryAdapter.DeleteWeightListener {

    private RecyclerView recyclerView;
    private WeightEntryAdapter adapter;
    private WeightRepository weightRepository;
    private GoalService goalService;
    private List<WeightEntry> weightEntries;
    private GoalWeight goalWeight;
    private int userId; // User-specific ID
    private AppDatabase database;

    //When Main activity is started
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //create set up from XML layout
        setContentView(R.layout.activity_main);
        //Set up tool bar at the top of the screen
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        database = AppDatabase.getInstance(this);
        //Sets up weight repository and goal service for use
        weightRepository = new WeightRepository(database.weightEntryDao());
        goalService = new GoalService(database.goalWeightDao());

        // Retrieve userId from intent
        userId = getIntent().getIntExtra("USER_ID", -1);
        //if user Id doesn't exist
        if (userId == -1) {
            Toast.makeText(this, "Invalid user ID.", Toast.LENGTH_SHORT).show();
            finish();
            return;
            }

        // Set up RecyclerView
        recyclerView = findViewById(R.id.dataRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load user-specific goal weight and weight entries
        loadData();

        // Set up FAB to add data
        FloatingActionButton fabAddData = findViewById(R.id.fabAddData);
        fabAddData.setOnClickListener(v -> showAddWeightDialog());
    }

    //set up goal service and weight repository to be used.
    private void loadData() {
        new Thread(() -> {
            goalWeight = goalService.getGoal(userId);
            weightEntries = weightRepository.getEntries(userId);
            //updates adapter to set up grid of weight entries
            runOnUiThread(() -> {
                adapter = new WeightEntryAdapter(weightEntries, goalWeight, this);
                recyclerView.setAdapter(adapter);
            });
        }).start();
    }

    //inflates the app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    //Sets up "Scale" icon button in app bar and calls method to update goal weight when clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_set_goal) {
            showSetGoalWeightDialog();
            return true;
        }
        //added dashboard activity to dropdown menu
        if (item.getItemId() == R.id.action_dashboard) {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            return true;
        }
        //if user clicks log out in the dropdown menu
        if (item.getItemId() == R.id.action_logout) {
            showLogoutConfirmation();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //Create a button to close main activity and return to login screen from dropdown menu in app bar
    private void logout() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);

        //Don't allow user to return to main activity with back button
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        startActivity(intent);
        finish();
    }

    //confirms if user wants to log out of application or not
    private void showLogoutConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes", (dialog, which) -> logout())
                .setNegativeButton("Cancel", null)
                .show();
    }

    //TODO add comments to explain
    //Uses a dialog box to update goal weight
    private void showSetGoalWeightDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_goal_and_height, null);

        EditText editGoal = dialogView.findViewById(R.id.editGoalWeight);
        EditText editFeet = dialogView.findViewById(R.id.editHeightFeet);
        EditText editInches = dialogView.findViewById(R.id.editHeightInches);

        new AlertDialog.Builder(this)
                .setTitle("Set Goal + Height")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String goalInput = editGoal.getText().toString();
                    String feetInput = editFeet.getText().toString();
                    String inchesInput = editInches.getText().toString();

                    InputValidator.InputValidationResult goalResult =
                            InputValidator.validateWeight(goalInput);
                    if (!goalResult.ok) {
                        Toast.makeText(this, goalResult.error, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    InputValidator.InputValidationResult heightResult =
                            InputValidator.validateHeightFeetInches(feetInput, inchesInput);
                    if (!heightResult.ok) {
                        Toast.makeText(this, heightResult.error, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double goalWeightValue = Double.parseDouble(goalResult.value);
                    int heightInchesTotal = Integer.parseInt(heightResult.value);

                    saveGoalWeight(goalWeightValue);

                    // Save height to the user record (DB write)
                    new Thread(() -> database.userDao().updateHeight(userId, heightInchesTotal)).start();

                    Toast.makeText(this, "Goal and height saved!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    //adds goal weight to database for specific user Id
    private void saveGoalWeight(double goalWeightValue) {
        new Thread(() -> {
            goalService.saveGoal(userId, goalWeightValue);
            goalWeight = goalService.getGoal(userId);

            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                    "Goal weight saved!", Toast.LENGTH_SHORT).show());
        }).start();
    }

    //when fab clicked, dialog box is opened to input date and weight entry and passed to saveWeightEntry method
    private void showAddWeightDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight_entry, null);
        EditText editTextDate = dialogView.findViewById(R.id.editTextDate);
        EditText editTextWeight = dialogView.findViewById(R.id.editTextWeight);

        new AlertDialog.Builder(this)
                //sets up date and uses a default if input empty
                .setTitle("Add Weight Entry")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String dateInput = editTextDate.getText().toString();
                    String weightInput = editTextWeight.getText().toString();

                    InputValidator.InputValidationResult dateResult =
                            InputValidator.validateDate(dateInput);

                    if (!dateResult.ok) {
                        Toast.makeText(this, dateResult.error, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    InputValidator.InputValidationResult weightResult =
                            InputValidator.validateWeight(weightInput);

                    if (!weightResult.ok) {
                        Toast.makeText(this, weightResult.error, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double currentWeight = Double.parseDouble(weightResult.value);
                    saveWeightEntry(dateResult.value, currentWeight);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    //Adds weight entry to database and updates recyclerView to add new entry to grid
    private void saveWeightEntry(String date, double weight) {
        new Thread(() -> {
            //add weight entry to database
            weightRepository.addEntry(new WeightEntry(date, weight, userId));
            //saves all weight entries by specific user Id
            weightEntries = weightRepository.getEntries(userId);

            runOnUiThread(() -> {
                //sets up weight entries in grid
                adapter.setWeightEntries(weightEntries);
                Toast.makeText(this, "Weight entry saved.", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }

    //deletes a weight entry from the database and updates the RecyclerView to remove the deleted entry
    @Override
    public void onDeleteWeightEntry(WeightEntry entry) {
        new Thread(() -> {
            //deletes from database
            weightRepository.deleteEntry(entry);
            //updates grid of weight entries
            List<WeightEntry> updated = weightRepository.getEntries(userId);

            runOnUiThread(() -> {
                adapter.setWeightEntries(updated);
                Toast.makeText(this, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }
}
