package com.CS360.weighttracker.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.CS360.weighttracker.model.User;
@Dao
public interface UserDAO {

    //Adds new user
    @Insert(onConflict = OnConflictStrategy.ABORT)
    long insert(User user);

    //Gets username for individual.Parameterize SQL queries to prevent SQL injection attacks
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByUsername(String username);

    //Gets userId for individual.Parameterize SQL queries to prevent SQL injection attacks
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    User getUserById(int userId);

    //Update height for the user
    @Query("UPDATE users SET heightInches = :heightInches WHERE id = :userId")
    void updateHeight(int userId, int heightInches);

    //Read height
    @Query("SELECT heightInches FROM users WHERE id = :userId LIMIT 1")
    int getHeightInches(int userId);
}