/*
 * Christopher DeMello
 * Dr. Godbold
 * CS360 Mod 7-2
 * 15 Dec 2024
 * Modified: 1/22/25
 * */

package com.CS360.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.CS360.weighttracker.model.User;
import com.CS360.weighttracker.Dao.AppDatabase;
import com.CS360.weighttracker.service.AuthService;
import com.CS360.weighttracker.util.InputValidator;

//Logic behind login screen. It allows a user to create an acct or login into existing account.

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private AuthService authService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Initialize UI components
        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);

        //Sets up service for User Dao
        AppDatabase database = AppDatabase.getInstance(this);
        authService = new AuthService(database.userDao());

        //Sets up button click listeners
        findViewById(R.id.buttonLogin).setOnClickListener(view -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            //Validates username through inputvalidator class
            InputValidator.InputValidationResult usernameResult = InputValidator.validateUsername(username);
            //if username not acceptable, display message
            if (!usernameResult.ok) {
                Toast.makeText(this, usernameResult.error, Toast.LENGTH_SHORT).show();
                return;
            }
            //Validates password through inputvalidator class
            InputValidator.InputValidationResult passwordResult = InputValidator.validatePassword(password);
            //if username not acceptable, display message
            if (!passwordResult.ok) {
                Toast.makeText(this, passwordResult.error, Toast.LENGTH_SHORT).show();
                return;
            }
            //lets user sign if username and password are acceptable
            loginUser(usernameResult.value, passwordResult.value);
        });
        //Sets up button click listeners
        findViewById(R.id.buttonCreateAccount).setOnClickListener(view -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();
            //Validates username through inputvalidator class
            InputValidator.InputValidationResult usernameResult = InputValidator.validateUsername(username);
            //if username not acceptable, display message
            if (!usernameResult.ok) {
                Toast.makeText(this, usernameResult.error, Toast.LENGTH_SHORT).show();
                return;
            }
            //Validates username through inputvalidator class
            InputValidator.InputValidationResult passwordResult = InputValidator.validatePassword(password);
            //if password not acceptable, display message
            if (!passwordResult.ok) {
                Toast.makeText(this, passwordResult.error, Toast.LENGTH_SHORT).show();
                return;
            }
            //Creates new username and password if both are accceptable
            registerUser(usernameResult.value, passwordResult.value);
        });
    }


     // Logs in a user with the existing username and password.
    private void loginUser(String username, String password) {
        //checks database for matching username
        new Thread(() -> {

            User user = authService.authenticate(username, password);
            //signs user into personal profile if not null
            runOnUiThread(() -> {
                if (user != null) {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

                    //checks sms permission, if not checked, brings to sms notification screen
                    Intent intent = new Intent(this, MainActivity.class);
                    intent.putExtra("USER_ID", user.getId());
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }


     //Registers a new user with the provided username and password.=
    private void registerUser(String username, String password) {
        new Thread(() -> {
            //uses authservice class to determine if username and password are valid
            boolean success = authService.register(username, password);

            runOnUiThread(() -> {
                //lets user create account and sign in
                if (success) {
                    Toast.makeText(this, "Registration successful. You may login into your account.",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}