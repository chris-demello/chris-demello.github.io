package com.CS360.weighttracker.model;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;
//Modified: Add secure storage with hashing

//Creates a users Entity that saves username, password, and user's permission request
@Entity(
        tableName = "users"
)
public class User {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String username;
    private String passwordHash;
    private String passwordSalt;
    private int passwordIters;

    //stores inches to calculate BMI
    private int heightInches;


    public User() {}
    // Constructor
    public User(String username, String passwordHash,
                String passwordSalt, int passwordIters) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.passwordSalt = passwordSalt;
        this.passwordIters = passwordIters;

    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getPasswordSalt() {
        return passwordSalt;
    }

    public void setPasswordSalt(String passwordSalt) {
        this.passwordSalt = passwordSalt;
    }

    public int getPasswordIters() {
        return passwordIters;
    }

    public void setPasswordIters(int passwordIters) {
        this.passwordIters = passwordIters;
    }

    public int getHeightInches() { return heightInches; }

    public void setHeightInches(int heightInches) { this.heightInches = heightInches; }

}