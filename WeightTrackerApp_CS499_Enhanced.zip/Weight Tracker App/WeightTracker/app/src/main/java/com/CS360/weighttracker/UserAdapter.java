package com.CS360.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.CS360.weighttracker.model.User;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    private final List<User> users;

    public UserAdapter(List<User> users) {
        this.users = users;
    }
    //Creates new viewholder for the recyclerview
    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.weight_entry, parent, false);
        return new UserViewHolder(view);
    }
    //binds data specific for a user
    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        User user = users.get(position);
        holder.dateTextView.setText(user.getUsername());
        holder.weightTextView.setText(user.getPasswordHash());
    }

    //returns size of all users
    @Override
    public int getItemCount() {

        return users.size();
    }

    //References a single user
    static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView, weightTextView;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.date);
            weightTextView = itemView.findViewById(R.id.weight);
        }
    }
}
