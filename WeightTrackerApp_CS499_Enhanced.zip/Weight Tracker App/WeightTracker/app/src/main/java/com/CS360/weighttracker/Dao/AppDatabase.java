package com.CS360.weighttracker.Dao;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.CS360.weighttracker.model.GoalWeight;
import com.CS360.weighttracker.model.User;
import com.CS360.weighttracker.model.WeightEntry;

@Database(entities = {User.class, WeightEntry.class, GoalWeight.class}, version = 7, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDAO userDao();
    public abstract WeightEntryDAO weightEntryDao();
    public abstract GoalWeightDAO goalWeightDao();

    private static AppDatabase INSTANCE;

    public static synchronized AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "app_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(new RoomDatabase.Callback() {
                        @Override
                        public void onCreate(@NonNull SupportSQLiteDatabase db) {
                            super.onCreate(db);
                            // Any additional setup code for database creation
                        }

                        @Override
                        public void onOpen(@NonNull SupportSQLiteDatabase db) {
                            super.onOpen(db);
                            // Code to handle database opening
                        }
                    })

                    .build();
        }
        return INSTANCE;
    }

}