package com.CS360.weighttracker.Dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.CS360.weighttracker.model.WeightEntry;

import java.util.List;

@Dao
public interface WeightEntryDAO {
    @Insert
    void insert(WeightEntry weightEntry);

    //gets all weight entries in a list for a specific user id
    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY id DESC")
    List<WeightEntry> getAllWeightEntries(int userId);

    @Delete
    void delete(WeightEntry weightEntry);
}