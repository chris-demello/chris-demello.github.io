package com.CS360.weighttracker.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.CS360.weighttracker.model.User;

@Dao
public interface UserDAO {
    @Insert
    void insert(User user);

    //gets a user's username and password
    @Query("SELECT * FROM users WHERE username = :username AND password = :password")
    User getUser(String username, String password);

    //gets a user's Id
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    User getUserById(int userId);

    //gets a user's username
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByUsername(String username);
}