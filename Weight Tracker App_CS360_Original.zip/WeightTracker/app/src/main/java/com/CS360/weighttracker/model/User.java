package com.CS360.weighttracker.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

//Creates a users Entity that saves username, password, and user's permission request
@Entity(tableName = "users")
public class User {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String username;
    private String password;
    private boolean hasPermission;

    // Constructor
    public User(String username, String password, boolean hasPermission) {
        this.username = username;
        this.password = password;
        this.hasPermission = hasPermission;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setHasPermission(boolean permission) {
        this.hasPermission = permission;
    }

    public boolean getHasPermission() {
        return hasPermission;
    }
}