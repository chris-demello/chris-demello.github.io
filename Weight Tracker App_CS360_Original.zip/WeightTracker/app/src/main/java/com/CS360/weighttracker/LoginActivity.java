/*
 * Christopher DeMello
 * Dr. Godbold
 * CS360 Mod 7-2
 * 15 Dec 2024
 * */

package com.CS360.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.CS360.weighttracker.model.User;
import com.CS360.weighttracker.Dao.AppDatabase;

//Logic behind login screen. It allows a user to create an acct or return.

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText, passwordEditText;
    private AppDatabase database;
    private boolean hasPermission = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Initialize UI components
        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        database = AppDatabase.getInstance(this);

        //Sets up button click listeners
        findViewById(R.id.buttonLogin).setOnClickListener(view -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Validate input
            if (validateInput(username, password)) {
                loginUser(username, password);
            }
        });
        //Sets up button click listeners
        findViewById(R.id.buttonCreateAccount).setOnClickListener(view -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Validate input
            if (validateInput(username, password)) {
                registerUser(username, password);
            }
        });
    }


     // Logs in a user with the existing username and password.
    private void loginUser(String username, String password) {
        //checks database for matching username
        new Thread(() -> {
            User user = database.userDao().getUserByUsername(username);
            //signs user into personal profile if not null
            if (user != null) {
                int userId = user.getId();
                runOnUiThread(() -> {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                    //checks sms permission, if not checked, brings to sms notification screen
                    if (!user.getHasPermission()) {
                        Intent intent = new Intent(LoginActivity.this,
                                SmsPermissionActivity.class);
                        startActivity(intent);
                    }

                    // Continues to pass userId to next activity
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.putExtra("USER_ID", userId);
                    startActivity(intent);
                    finish();
                });
                //if no match found, prompt following message
            } else {
                runOnUiThread(() -> Toast.makeText(this, "Invalid username or password!", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }


     //Registers a new user with the provided username and password.=
    private void registerUser(String username, String password) {
        new Thread(() -> {
            // Check if the username already exists
            User existingUser = database.userDao().getUserByUsername(username); // Simplified check
            if (existingUser == null) {
                // Create and insert new user
                User user = new User(username, password, hasPermission);
                database.userDao().insert(user);

                runOnUiThread(() -> Toast.makeText(this, "Registration successful! You can now log in.", Toast.LENGTH_SHORT).show());
            } else {
                runOnUiThread(() -> Toast.makeText(this, "Username already exists. Please choose a different one.", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

     //Validates the username and password input fields.
    private boolean validateInput(String username, String password) {
        if (username.isEmpty()) {
            Toast.makeText(this, "Username cannot be empty!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Password cannot be empty!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters long!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}