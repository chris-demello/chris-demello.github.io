package com.CS360.weighttracker.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

//creates weight entries entity that saves the date, weight and userId
@Entity(tableName = "weight_entries")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String date;
    private double weight;
    private int userId; // Foreign key association to the user

    public WeightEntry(String date, double weight, int userId) {
        this.date = date;
        this.weight = weight;
        this.userId = userId;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
