package com.CS360.weighttracker.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

//Creates a goal weight entity that is used to save goal weight in a database per userId
@Entity
public class GoalWeight {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private int userId;
    private double weight;

    // Default constructor (required by Room)
    public GoalWeight() {
    }

    // Parameterized constructor
    public GoalWeight(double weight, int userId) {
        this.weight = weight;
        this.userId = userId;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}
