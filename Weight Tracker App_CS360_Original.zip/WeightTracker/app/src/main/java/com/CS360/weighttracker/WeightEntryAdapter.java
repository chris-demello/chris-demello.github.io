package com.CS360.weighttracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.CS360.weighttracker.model.GoalWeight;
import com.CS360.weighttracker.model.WeightEntry;

import java.util.List;

public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.ViewHolder> {
    private List<WeightEntry> weightEntries;
    private GoalWeight goalWeight;
    private DeleteWeightListener deleteWeightListener;

    // Constructor
    public WeightEntryAdapter(List<WeightEntry> weightEntries, GoalWeight goalWeight, DeleteWeightListener deleteWeightListener) {
        this.weightEntries = weightEntries;
        this.goalWeight = goalWeight;
        this.deleteWeightListener = deleteWeightListener;
    }

    //creates a new viewholder object to represent a row in the recyclerView
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_entry, parent, false);
        return new ViewHolder(view);
    }
    //binds data to viewholder for that weight entry specific position
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.tvDate.setText(entry.getDate());
        holder.tvWeight.setText(entry.getWeight() + " lbs");

        // Calculate and display differential if goalWeight exists
        if (goalWeight != null) {
            double differential = (goalWeight.getWeight() - entry.getWeight()) * -1;
            holder.tvDifferential.setText(differential + " lbs");
        } else {
            holder.tvDifferential.setText("N/A");
        }

        // Set delete button click listener to notify activity
        holder.btnDelete.setOnClickListener(v -> {
            if (deleteWeightListener != null) {
                deleteWeightListener.onDeleteWeightEntry(entry);
            }
        });
    }
    //returns the number of all the rows in weight entries list
    @Override
    public int getItemCount() {

        return weightEntries.size();
    }

    //Removes a weight entry from a specific position in the recyclerview
    public void removeWeightEntry(int position) {
        weightEntries.remove(position);
        notifyItemRemoved(position);
    }

    //Updates the weight entries list with new data and refreshes the recyclerview
    public void setWeightEntries(List<WeightEntry> weightEntries) {
        this.weightEntries = weightEntries;
        notifyDataSetChanged();  // Refresh the entire dataset
    }

    //shows a single row and the details about that row
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight, tvDifferential;
        ImageButton btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.date);
            tvWeight = itemView.findViewById(R.id.weight);
            tvDifferential = itemView.findViewById(R.id.differential);
            btnDelete = itemView.findViewById(R.id.delete);
        }
    }

    // Interface for delete callback
    public interface DeleteWeightListener {
        void onDeleteWeightEntry(WeightEntry weightEntry);
    }
}
