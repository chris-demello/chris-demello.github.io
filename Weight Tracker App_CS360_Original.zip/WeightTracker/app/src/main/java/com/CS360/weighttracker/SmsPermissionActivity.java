/*
 * Christopher DeMello
 * Dr. Godbold
 * CS360 Mod 7-2
 * 15 Dec 2024
 * */
package com.CS360.weighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class SmsPermissionActivity extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 1;
    private SwitchCompat smsPermissionSwitch;
    private Button btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_notification);  // Use the sms_notifications.xml layout

        smsPermissionSwitch = findViewById(R.id.smsPermission);
        btnCancel = findViewById(R.id.btnCancel);

        // Check if SMS permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsPermissionSwitch.setChecked(true);
            smsPermissionSwitch.setEnabled(true);
        }

        // Handle switch toggling
        smsPermissionSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Request SMS permission if not already granted
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
                    smsPermissionSwitch.setChecked(true);
                    smsPermissionSwitch.setEnabled(true);
                }
            }
        });

        // Handle Cancel button click
        btnCancel.setOnClickListener(v -> {
            // Finish the activity and go back to MainActivity (or previous screen)
            finish();
        });
    }

    //manages the result of the permission request after the user responds to the permission dialog
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsPermissionSwitch.setChecked(true);  // Enable switch if permission is granted
            } else {
                smsPermissionSwitch.setChecked(false);  // Keep switch off if permission is denied
            }
        }
    }
}
