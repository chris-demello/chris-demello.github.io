/*
* Christopher DeMello
* Dr. Godbold
* CS360 Mod 7-2
* 15 Dec 2024
* */

package com.CS360.weighttracker;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.CS360.weighttracker.model.GoalWeight;
import com.CS360.weighttracker.model.WeightEntry;
import com.CS360.weighttracker.Dao.AppDatabase;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/*
Logic behind main activity. This allows a user to view the grid system (recyclerview) where a user
can set their goal weight by clicking the scale icon in the app bar. The user can set their daily
weight entry with the FAB in the bottom right. The user can delete any row by clicking on the trash
can.
 */

public class MainActivity extends AppCompatActivity {
    private AppDatabase database;
    private RecyclerView recyclerView;
    private WeightEntryAdapter adapter;
    private List<WeightEntry> weightEntries;
    private GoalWeight goalWeight;
    private int userId; // User-specific ID
    private boolean smsPermissionGranted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        database = AppDatabase.getInstance(this);

        // Check if SMS permission is granted

        // If permission is not granted, navigate to the SmsPermissionActivity
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(this, SmsPermissionActivity.class);
            startActivity(intent);
        } else {

            // Retrieve userId from intent
            userId = getIntent().getIntExtra("USER_ID", -1);

            if (userId == -1) {
                Toast.makeText(this, "Invalid user ID.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // Set up RecyclerView
            recyclerView = findViewById(R.id.dataRecyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            // Load user-specific goal weight and weight entries
            loadGoalWeight(userId);
            loadWeightEntries(userId);

            // Set up FAB to add data
            FloatingActionButton fabAddData = findViewById(R.id.fabAddData);
            fabAddData.setOnClickListener(v -> showAddWeightDialog());
        }
    }

    //grabs the goal weight specific for user Id
    private void loadGoalWeight(int userId) {
        new Thread(() -> {
            goalWeight = database.goalWeightDao().getGoalWeightForUser(userId);
            runOnUiThread(() -> {
                if (goalWeight == null) {
                    Toast.makeText(this, "No goal weight set for this user.", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();

    }

    //grabs the weight entries that are specific per user Id and loads in the recyclerView
    private void loadWeightEntries(int userId) {
        new Thread(() -> {
            weightEntries = database.weightEntryDao().getAllWeightEntries(userId);
            runOnUiThread(() -> {
                adapter = new WeightEntryAdapter(weightEntries, goalWeight, this::onDeleteWeightEntry);
                recyclerView.setAdapter(adapter);
            });
        }).start();
    }

    //inflates the app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    //Sets up "Scale" icon button in app bar and calls method to update goal weight when clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_set_goal) {
            showSetGoalWeightDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    //TODO Create a button to navigate to SMS notifications screen from dropdown menu in app bar

    //TODO Create a button to close main activity and return to login screen from dropdown menu in app bar

    //Uses a dialog box to update goal weight
    private void showSetGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        //sets up user input
        final EditText input = new EditText(this);
        input.setHint("Enter your goal weight");
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        builder.setView(input);
        //if save clicked, checks user input and sends to be saved in goal weight database
        builder.setPositiveButton("Save", (dialog, which) -> {
            String goalWeightStr = input.getText().toString();
            if (!goalWeightStr.isEmpty()) {
                try {
                    double goalWeightValue = Double.parseDouble(goalWeightStr);
                    saveGoalWeight(goalWeightValue);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Invalid weight entered", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Weight cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });
        //cancels goal weight input
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    //adds goal weight to database for specific user Id
    private void saveGoalWeight(double goalWeightValue) {
        new Thread(() -> {
            GoalWeight goal = new GoalWeight(goalWeightValue, userId); // Include userId
            database.goalWeightDao().insert(goal);
            loadGoalWeight(userId);
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Goal weight saved!", Toast.LENGTH_SHORT).show());
        }).start();
    }

    //when fab clicked, dialog box is opened to input date and weight entry and passed to saveWeightEntry method
    private void showAddWeightDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight_entry, null);
        EditText editTextDate = dialogView.findViewById(R.id.editTextDate);
        EditText editTextWeight = dialogView.findViewById(R.id.editTextWeight);

        new AlertDialog.Builder(this)
                //sets up date and uses a default if input empty
                .setTitle("Add Weight Entry")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String date = editTextDate.getText().toString();
                    if (date.isEmpty()) {
                        date = getCurrentDate(); // Default to today's date if none is entered
                    }
                    //sets up weight and checks to make sure not empty
                    String weightInput = editTextWeight.getText().toString();

                    if (weightInput.isEmpty()) {
                        Toast.makeText(this, "Please fill the weight field.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    //validates weight is acceptable input and passes data to be saved to database
                    try {
                        double currentWeight = Double.parseDouble(weightInput);
                        saveWeightEntry(date, currentWeight);
                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid weight input.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String getCurrentDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }
    //Adds weight entry to database and updates recyclerView to add new entry to grid
    private void saveWeightEntry(String date, double currentWeight) {
        new Thread(() -> {
            if (goalWeight == null) {
                runOnUiThread(() -> Toast.makeText(this, "No goal weight set.", Toast.LENGTH_SHORT).show());
                return;
            }

            WeightEntry weightEntry = new WeightEntry(date, currentWeight, userId);

            database.weightEntryDao().insert(weightEntry);
            runOnUiThread(() -> {
                Toast.makeText(this, "Weight entry saved.", Toast.LENGTH_SHORT).show();
                refreshRecyclerView(userId);
            });
        }).start();
    }

    //TODO Create logic to send SMS message when current weight is equal to or less than goal weight

    public void onDeleteWeightEntry(WeightEntry weightEntry) {
        deleteWeightEntry(weightEntry);
    }

    //deletes a weight entry from the database and updates the RecyclerView to remove the deleted entry
    public void deleteWeightEntry(WeightEntry weightEntry) {
        new Thread(() -> {
            database.weightEntryDao().delete(weightEntry);  // Delete from DB
            runOnUiThread(() -> {
                // Remove from the adapter
                adapter.removeWeightEntry(weightEntries.indexOf(weightEntry));
                Toast.makeText(this, "Weight entry deleted.", Toast.LENGTH_SHORT).show();
            });
        }).start();
    }
    // refreshes the list of weight entries in the RecyclerView
    private void refreshRecyclerView(int userId) {
        new Thread(() -> {
            weightEntries = database.weightEntryDao().getAllWeightEntries(userId);
            runOnUiThread(() -> {
                adapter.setWeightEntries(weightEntries);
                adapter.notifyDataSetChanged();
            });
        }).start();
    }
}
