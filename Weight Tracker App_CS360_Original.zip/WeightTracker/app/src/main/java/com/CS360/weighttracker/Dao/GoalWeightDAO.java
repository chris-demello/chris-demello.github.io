package com.CS360.weighttracker.Dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.CS360.weighttracker.model.GoalWeight;

@Dao
public interface GoalWeightDAO {

    //grabs goal weight for specific user Id
    @Query("SELECT * FROM GoalWeight WHERE userId = :userId LIMIT 1")
    GoalWeight getGoalWeightForUser(int userId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(GoalWeight goalWeight);
}
